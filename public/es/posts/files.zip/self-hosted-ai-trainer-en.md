---
title: I built a private AI personal trainer that runs on my home server
published: true
description: How I put together a self-hosted fitness assistant using Ollama, n8n, and Telegram — no subscriptions, no cloud, no data leaving my house.
tags: ollama, n8n, selfhosted, fitness
cover_image:
---

I've been training seriously for years — mainly weightlifting and cycling. And like most people who track their workouts obsessively, I eventually asked myself: do I really need another subscription, another app asking for my health data, another AI service I don't control?

I decided to build my own instead.

## The idea

I wanted a fitness assistant that actually *knew* me. My goals, my recent sessions, whether I'd done a long ride the day before, whether I was in a strength or a cutting phase. Something that would use all of that context to suggest a sensible training plan for the day.

Nothing a human coach can't do. But I wanted it to run locally, on hardware I own, without sending my health data anywhere. And I wanted to build it myself.

I called it **Carson** — my local AI personal trainer.

## The stack

Here's what I put together, with a quick explanation for each piece in case you're not deep into self-hosting:

**Ollama** runs AI models directly on your own machine — no internet required, no API keys, no usage costs. It's the brain of the whole thing. I used `llama3.2:3b`, a compact model that runs on modest hardware.

**n8n** is an open-source workflow automation platform — think Zapier or Make, but self-hosted and much more flexible. This is where all the logic lives: what triggers Carson, what data it collects, how it formats the prompt, what it does with the response.

**PostgreSQL** stores everything: user profile, training history, generated plans, onboarding answers.

**Telegram Bot** is the interface. No mobile app to build or maintain — just a bot that I chat with to log sessions, request my daily plan, or get reminders with inline buttons.

**Proxmox + LXC containers** — my home server runs Proxmox, and each service lives in its own lightweight container. The whole stack uses surprisingly little RAM.

**Cloudflare Tunnel** — and this is the detail nobody warns you about.

When you self-host n8n, it's completely isolated from the outside world by default. No public URL, no inbound connections. Your home IP changes periodically, it sits behind a router, and even if you forwarded a port, you'd be exposing your home network directly to the internet.

The problem with Telegram bots is that they work via webhooks: when someone messages your bot, Telegram needs to call *your* URL to deliver it. If n8n has no public URL, the bot receives nothing — and there's no obvious error. It just silently doesn't work.

Cloudflare Tunnel solves this cleanly. Instead of letting the outside world reach your server, your server opens an outbound connection to Cloudflare, which acts as the relay. The result: a stable public HTTPS URL, no open ports, no exposed IP, and free for this use case.

This step is missing from most n8n + Telegram tutorials, and it's exactly where most people get stuck wondering why their bot never responds.

## How it actually works

When I wake up, Carson already has context. If I did a two-hour ride yesterday — pulled from Strava — it knows. If I trained legs the day before, it won't load up squats again today.

The daily plan flow looks roughly like this:

```
1. Pull user profile and current goals from PostgreSQL
2. Query recent training history (last 7 days)
3. Fetch latest Strava activity (distance, effort, type)
4. Build a context-rich prompt
5. Send to Ollama → get training plan
6. Push to user via Telegram
```

New users go through an onboarding flow first — a series of questions about goals, experience level, available equipment, and preferences. All of that gets stored and used as permanent context for every subsequent interaction.

Evening reminders go out via Telegram with quick-reply buttons to log the session without typing. That data feeds back into the history for the next day's plan.

## What I learned

**Prompt design matters more than the model.** The quality of Carson's plans depends heavily on how much useful context I give the AI and how I structure the prompt. A vague prompt gets a generic plan. A well-structured one — with goals, recent load, and today's available time — gets something actually useful.

**Small models have real limitations.** `llama3.2:3b` is impressive for its size, but it occasionally generates generic responses or ignores formatting instructions. If you want consistently structured output, you either need a larger model or you invest more in prompt engineering and output parsing.

**n8n is genuinely powerful for this kind of project.** The visual workflow builder makes it easy to iterate quickly. The hardest part wasn't the automation — it was designing the data model and the conversation flow so that context accumulated correctly over time.

**Self-hosting means you're the sysadmin.** Full data privacy comes at the cost of maintenance. If something breaks, that's on you. For me that's fine — I enjoy it. For most people, it's a genuine tradeoff to consider.

## Is it worth building?

If you're a developer curious about local AI, workflow automation, and self-hosting — yes, absolutely. The learning value alone justifies it, regardless of how good the training plans turn out.

If you just want an AI training assistant without the infrastructure work, ChatGPT with a well-crafted prompt will probably give you comparable results with a fraction of the effort.

Where Carson wins is privacy and long-term cost. My health and training data never leaves my house. There's no subscription to cancel, no API costs, no Terms of Service that change overnight.

---

*Interested in the n8n workflow structure or how I designed the prompts? Let me know in the comments — happy to go deeper on either in a follow-up post.*
